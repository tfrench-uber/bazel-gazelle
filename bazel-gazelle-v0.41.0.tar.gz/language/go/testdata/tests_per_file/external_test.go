package tests_per_file_test

import (
	"testing"

	"example.com/repo/tests_per_file"
)

func TestStuff(t *testing.T) {
	var _ tests_per_file.Type
}
