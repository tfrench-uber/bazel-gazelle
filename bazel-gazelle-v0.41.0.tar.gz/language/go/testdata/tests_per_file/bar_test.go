package tests_per_file

import "testing"

func TestStuff(t *testing.T) {}
