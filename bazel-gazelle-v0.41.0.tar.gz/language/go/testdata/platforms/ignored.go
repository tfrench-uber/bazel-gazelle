//go:build ignore
// +build ignore

package platforms
