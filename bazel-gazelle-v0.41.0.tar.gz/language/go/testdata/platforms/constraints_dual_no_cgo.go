// +build !cgo appengine
//
// !cgo || appengine == true ∵
// !cgo == true

package platforms
