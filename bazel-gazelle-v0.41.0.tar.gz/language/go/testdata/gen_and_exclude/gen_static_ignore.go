//go:build ignore
// +build ignore

package gen_and_exclude
