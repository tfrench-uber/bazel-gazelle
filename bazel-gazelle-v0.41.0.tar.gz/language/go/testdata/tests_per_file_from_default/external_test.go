package tests_per_file_from_default_test

import (
	"testing"

	"example.com/repo/tests_per_file_from_default"
)

func TestStuff(t *testing.T) {
	var _ tests_per_file_from_default.Type
}
