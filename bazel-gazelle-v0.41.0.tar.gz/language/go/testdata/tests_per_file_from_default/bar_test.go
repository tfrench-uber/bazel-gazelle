package tests_per_file_from_default

import "testing"

func TestOtherStuff(t *testing.T) {}
