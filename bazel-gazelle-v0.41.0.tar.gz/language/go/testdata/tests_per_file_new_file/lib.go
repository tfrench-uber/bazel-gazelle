package tests_per_file_new_file

type Type int
