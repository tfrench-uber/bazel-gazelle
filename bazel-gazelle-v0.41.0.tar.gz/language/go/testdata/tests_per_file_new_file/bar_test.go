package tests_per_file_new_file

import "testing"

func TestStuff(t *testing.T) {}
