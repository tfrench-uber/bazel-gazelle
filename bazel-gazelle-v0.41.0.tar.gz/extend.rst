Extending Gazelle
=================

`Moved to markdown <./extend.md>`_
