# Gazelle warns on invalid directive use
