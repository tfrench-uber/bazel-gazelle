# Fix go_proto_library dependencies

Fix go_proto_library dependencies when package and proto name match
