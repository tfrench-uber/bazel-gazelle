# No errors no output

When Gazelle is run in a repo that doesn't have any errors it should be silent
and exit with a 0 exit code.
