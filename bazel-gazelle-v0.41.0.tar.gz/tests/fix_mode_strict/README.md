# Gazelle fix -strict mode

When Gazelle is run with the `-strict` flag, it will exit with none-zero value
for build file syntax errors or unknown directives.
