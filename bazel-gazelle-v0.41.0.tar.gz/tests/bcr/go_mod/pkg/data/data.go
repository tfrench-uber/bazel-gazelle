package data

const RepoConfigRlocationPath = "bazel_gazelle_go_repository_config/WORKSPACE"
