# Gazelle diff mode

When Gazelle is run with the `-mode=diff` flag, it prints out the diff that
Bazel would have applied.
