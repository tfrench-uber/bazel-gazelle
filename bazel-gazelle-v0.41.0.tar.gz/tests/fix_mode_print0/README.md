# Fix mode with -print0

Prints all fixed files with \0 as delimiter.
