# Fix load statements for packed rules in struct

Fixes load statement for newly generated `select.config_setting_group` rule.
